import { Component, Input } from '@angular/core';
import { Hero } from './hero';
@Component({
  selector: 'my-hero-detail',
  template: `
    <div *ngIf="hero">
      <h2>{{hero.name}} listed exercises</h2>
      <div><label>Exercise 1: </label>{{hero.exercise1}}</div>
      <br>
      <div><label>Exercise 2: </label>{{hero.exercise2}}</div>
      <br>
      <div><label>Exercise 3: </label>{{hero.exercise3}}</div>
      <br>
      <div><label>Exercise 4: </label>{{hero.exercise4}}</div>
      <br>
      <div><label>Exercise 5: </label>{{hero.exercise5}}</div>
      <br>
      <div><label>Exercise 6: </label>{{hero.exercise6}}</div>
      
    </div>
  `
})
export class HeroDetailComponent {
  @Input()
  hero: Hero;
}
