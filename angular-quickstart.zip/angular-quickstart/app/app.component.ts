import { Component } from '@angular/core';
import { Hero } from './hero';
const HEROES: Hero[] = [

  { id: 1, name: 'Workout 1', exercise1: 'Cardio: Run on Treadmill for 10-15 minutes',
  exercise2: 'Bench Press:  4 Sets of 8-12 Reps', exercise3: 'Lat Pull Down: 4 Sets of 8-12 Reps',
  exercise4: 'Leg Extensions: 4 Sets of 8-12 Reps', exercise5: 'Hamstring Curls: 4 Sets of 8-12 Reps',
  exercise6: 'Crunches: 2 sets of 25'},
  
  { id: 2, name: 'Workout 2', exercise1: 'Cardio: Jump Rope for 5-10 minutes',
  exercise2: 'Machine Squat:  4 Sets of 8-12 Reps', exercise3: 'Machine Upward Row: 4 Sets of 8-12 Reps',
  exercise4: 'Shoulder Press: 4 Sets of 8-12 Reps', exercise5: 'Calve Raises: 4 Sets of 8-12 Reps',
  exercise6: 'Plank: 2 sets 1 minute'},
  
  { id: 3, name: 'Workout 3', exercise1: 'Cardio: Stair Master 10-15 minutes',
  exercise2: 'Bicep Barbell Curls:  4 Sets of 8-12 Reps', exercise3: 'Tricep Rope Extensions: 4 Sets of 8-12 Reps',
  exercise4: 'Lateral Shoulder Raises: 4 Sets of 8-12 Reps', exercise5: 'Lunges: 3 Sets of 8-12 Reps Each Leg',
  exercise6: 'Machine Crunches: 3 sets of 10-12 Reps'}
];
@Component({
  selector: 'my-app',
  template: `
    <h1>{{title}}</h1>
    <h2>Please click on the links listed below to view exercise information</h2>
    <ul class="heroes">
      <li *ngFor="let hero of heroes"
        [class.selected]="hero === selectedHero"
        (click)="onSelect(hero)">
        <span class="badge">{{hero.id}}</span> {{hero.name}}
      </li>
    </ul>
    <my-hero-detail [hero]="selectedHero"></my-hero-detail>
  `,
  styles: [`
    .selected {
      background-color: #CFD8DC !important;
      color: white;
    }
    .heroes {
      margin: 0 0 2em 0;
      list-style-type: none;
      padding: 0;
      width: 15em;
    }
    .heroes li {
      cursor: pointer;
      position: relative;
      left: 0;
      background-color: #EEE;
      margin: .5em;
      padding: .3em 0;
      height: 1.6em;
      border-radius: 4px;
    }
    .heroes li.selected:hover {
      background-color: #BBD8DC !important;
      color: white;
    }
    .heroes li:hover {
      color: #607D8B;
      background-color: #DDD;
      left: .1em;
    }
    .heroes .text {
      position: relative;
      top: -3px;
    }
    .heroes .badge {
      display: inline-block;
      font-size: small;
      color: white;
      padding: 0.8em 0.7em 0 0.7em;
      background-color: #607D8B;
      line-height: 1em;
      position: relative;
      left: -1px;
      top: -4px;
      height: 1.8em;
      margin-right: .8em;
      border-radius: 4px 0 0 4px;
    }
  `]
})
export class AppComponent {
  title = 'List of workouts';
  heroes = HEROES;
  selectedHero: Hero;
  onSelect(hero: Hero): void {
    this.selectedHero = hero;
  }
}
